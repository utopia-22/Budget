<?php $__env->startSection('content'); ?>
    <div>
        <?php echo e(__('Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one.')); ?>

    </div>

    <?php if(session('status')): ?>
        <div>
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div>
            <div><?php echo e(__('Whoops! Something went wrong.')); ?></div>

            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>

        <div>
            <label><?php echo e(__('Email')); ?></label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus />
        </div>

        <div>
            <button type="submit">
                <?php echo e(__('Email Password Reset Link')); ?>

            </button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Budget\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>