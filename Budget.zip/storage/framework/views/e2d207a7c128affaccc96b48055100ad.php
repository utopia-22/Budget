<form method="POST" action="<?php echo e(route('user-password.update')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div>
        <label><?php echo e(__('Current Password')); ?></label>
        <input type="password" name="current_password" required autocomplete="current-password" />
    </div>

    <div>
        <label><?php echo e(__('Password')); ?></label>
        <input type="password" name="password" required autocomplete="new-password" />
    </div>

    <div>
        <label><?php echo e(__('Confirm Password')); ?></label>
        <input type="password" name="password_confirmation" required autocomplete="new-password" />
    </div>

    <div>
        <button type="submit">
            <?php echo e(__('Save')); ?>

        </button>
    </div>
</form>

<hr>
<?php /**PATH C:\laragon\www\Budget\resources\views/profile/update-password-form.blade.php ENDPATH**/ ?>