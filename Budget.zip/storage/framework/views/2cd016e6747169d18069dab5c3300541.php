

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
	<?php if(session('success')): ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
			<?php echo e(session('success')); ?>

			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
	<?php endif; ?>

		<div class="col-md-2">
            <!-- Sidebar -->
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Sidebar -->
        </div>
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
					
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-md-12">
								<div class="text-center">
									<h4 class="card-title mt-2" style="color: red;">
										<?php
											$totalExpense = 0;
											foreach ($expenses as $expense) {
												$totalExpense += $expense->amount;
											}
										?>
										<strong>-RM <?php echo e($totalExpense); ?></strong>
									</h4>
								</div>
							</div>
						</div>
					</div>

				</div>

                <div class="card-body">

				<div class="row">
					<div class="col-3">

					<form action="<?php echo e(route('expense.store')); ?>" method="POST">
						<?php echo csrf_field(); ?>

						<div class="form-group my-2">
							<input name="title" type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title" value="<?php echo e(old('title')); ?>" placeholder="Title">
						
							<?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								<?php echo e($message); ?>

							</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>

						<div class="form-group my-2">
							<input name="amount" type="float" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="amount" value="<?php echo e(old('amount')); ?>" placeholder="Amount">
							
							<?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								<?php echo e($message); ?>

							</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>

						<div class="form-group my-2">
							<textarea name="description" id="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2" placeholder="Reference"><?php echo e(old('description')); ?></textarea>
						
							<?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<div class="invalid-feedback">
								<?php echo e($message); ?>

							</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>

						<button class="btn btn-primary">Submit</button>
					</form>

					</div>

					<div class="col-9">
					<?php if(!empty($expense->title)): ?>
						<div class="card">
							<div class="card-body">
							<div class="row">
								<?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="col-md-4 mb-3">
									<div class="card">
										<div class="card-body text-center">
											<h4 class="card-title" style="font-weight: bold;"><?php echo e($expense->title); ?></h4>
											<h5 class="card-text">RM <?php echo e($expense->amount); ?></h5>
											<p class="card-text"><?php echo e($expense->description); ?></p>
											<form class="d-inline" action="<?php echo e(route('expense.destroy', $expense->id)); ?>" method="POST" onsubmit="return confirm('Are you sure want to delete? <?php echo e($expense->source); ?>')" >
												<?php echo method_field('delete'); ?>
												<?php echo csrf_field(); ?>
												<button class="btn btn-danger btn-sm" type="submit">
													DELETE
												</button>
											</form>
										</div>
									</div>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							</div>
						</div>
					<?php endif; ?>
					</div>
						
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Budget\resources\views/expense.blade.php ENDPATH**/ ?>