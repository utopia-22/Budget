<form method="POST" action="<?php echo e(route('user-profile-information.update')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div>
        <label><?php echo e(__('Name')); ?></label>
        <input type="text" name="name" value="<?php echo e(old('name') ?? auth()->user()->name); ?>" required autofocus autocomplete="name" />
    </div>

    <div>
        <label><?php echo e(__('Email')); ?></label>
        <input type="email" name="email" value="<?php echo e(old('email') ?? auth()->user()->email); ?>" required autofocus />
    </div>

    <div>
        <button type="submit">
            <?php echo e(__('Update Profile')); ?>

        </button>
    </div>
</form>

<hr>
<?php /**PATH C:\laragon\www\Budget\resources\views/profile/update-profile-information-form.blade.php ENDPATH**/ ?>