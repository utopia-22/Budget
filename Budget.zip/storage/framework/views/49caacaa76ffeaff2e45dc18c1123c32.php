

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        
	<?php if(session('success')): ?>
		<div class="alert alert-success alert-dismissible fade show" role="alert">
			<?php echo e(session('success')); ?>

			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
	<?php endif; ?>

		<div class="col-md-2">
            <!-- Sidebar -->
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Sidebar -->
        </div>

		<div class="col-md-10">
			<div class="card">
				<div class="row">
					<div class="col-3">

					<form method="POST" action="<?php echo e(route('user-profile-information.update')); ?>">
						<?php echo csrf_field(); ?>
						<?php echo method_field('PUT'); ?>

						<div class="form-group mx-3 my-2">
							<label><?php echo e(__('Name')); ?></label>
							<input type="text" name="name" id="name" class="<?php $__errorArgs = ['source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name') ?? auth()->user()->name); ?>" required autofocus autocomplete="name" />

							<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="invalid-feedback">
									<?php echo e($message); ?>

								</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>

						<div class="form-group mx-3 my-2">
							<label><?php echo e(__('Email')); ?></label>
							<input type="email" name="email" disabled value="<?php echo e(old('email') ?? auth()->user()->email); ?>" required autofocus />
						</div>

						<div class="form-group mx-3 my-2">
							<button class="btn btn-success" type="submit">
								<?php echo e(__('Update Profile')); ?>

							</button>
						</div>
					</form>

					</div>
				</div>
			</div>

			<br>

			<div class="card">
				<div class="row">
					<div class="col-3">

					<form method="POST" action="<?php echo e(route('user-password.update')); ?>">
						<?php echo csrf_field(); ?>
						<?php echo method_field('PUT'); ?>

						<div class="form-group mx-3 my-2">
							<label><?php echo e(__('Current Password')); ?></label>
							<input type="password" name="current_password" required autocomplete="current-password" />
						</div>

						<div class="form-group mx-3 my-2">
							<label><?php echo e(__('New Password')); ?></label>
							<input type="password" name="password" required autocomplete="new-password" />
						</div>

						<div class="form-group mx-3 my-2">
							<label><?php echo e(__('Confirm Password')); ?></label>
							<input type="password" name="password_confirmation" required autocomplete="new-password" />
						</div>

						<div class="form-group mx-3 my-2">
							<button class="btn btn-success" type="submit">
								<?php echo e(__('Save')); ?>

							</button>
						</div>
					</form>

					</div>
				</div>
			</div>

			<div class="card my-2">
				<div class="row">
					<div class="col">
						<div class="form-group mx-3 my-2">
						<?php if(! auth()->user()->two_factor_secret): ?>
							
							<form method="POST" action="<?php echo e(route('two-factor.enable')); ?>">
								<?php echo csrf_field(); ?>

								<button class="btn btn-success" type="submit">
									<?php echo e(__('Enable Two-Factor')); ?>

								</button>
							</form>
						<?php else: ?>
							
							<form method="POST" action="<?php echo e(route('two-factor.disable')); ?>">
								<?php echo csrf_field(); ?>
								<?php echo method_field('DELETE'); ?>

								<button class="btn btn-success" type="submit">
									<?php echo e(__('Disable Two-Factor')); ?>

								</button>
							</form>

							<?php if(session('status') == 'two-factor-authentication-enabled'): ?>
								
								<div class="my-2">
									<?php echo e(__('Two factor authentication is now enabled. Scan the following QR code using your phone\'s authenticator application.')); ?>

								</div>

								<div>
									<?php echo auth()->user()->twoFactorQrCodeSvg(); ?>

								</div>
							<?php endif; ?>

							
							<div class="my-2">
								<?php echo e(__('Store these recovery codes in a secure password manager. They can be used to recover access to your account if your two factor authentication device is lost.')); ?>

							</div>

							<div>
								<ul>
									<?php $__currentLoopData = json_decode(decrypt(auth()->user()->two_factor_recovery_codes), true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li><?php echo e($code); ?></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>


							
							<form method="POST" action="<?php echo e(route('two-factor.recovery-codes')); ?>">
								<?php echo csrf_field(); ?>

								<button class="btn btn-success" type="submit">
									<?php echo e(__('Regenerate Recovery Codes')); ?>

								</button>
							</form>
						<?php endif; ?>
						</div>
					

					</div>
				</div>
			</div>
			
		</div>

	</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Budget\resources\views/profile.blade.php ENDPATH**/ ?>