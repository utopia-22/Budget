<?php if(! auth()->user()->two_factor_secret): ?>
    
    <form method="POST" action="<?php echo e(route('two-factor.enable')); ?>">
        <?php echo csrf_field(); ?>

        <button type="submit">
            <?php echo e(__('Enable Two-Factor')); ?>

        </button>
    </form>
<?php else: ?>
    
    <form method="POST" action="<?php echo e(route('two-factor.disable')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>

        <button type="submit">
            <?php echo e(__('Disable Two-Factor')); ?>

        </button>
    </form>

    <?php if(session('status') == 'two-factor-authentication-enabled'): ?>
        
        <div>
            <?php echo e(__('Two factor authentication is now enabled. Scan the following QR code using your phone\'s authenticator application.')); ?>

        </div>

        <div>
            <?php echo auth()->user()->twoFactorQrCodeSvg(); ?>

        </div>
    <?php endif; ?>

    
    <div>
        <?php echo e(__('Store these recovery codes in a secure password manager. They can be used to recover access to your account if your two factor authentication device is lost.')); ?>

    </div>

    <div>
        <?php $__currentLoopData = json_decode(decrypt(auth()->user()->two_factor_recovery_codes), true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($code); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <form method="POST" action="<?php echo e(route('two-factor.recovery-codes')); ?>">
        <?php echo csrf_field(); ?>

        <button type="submit">
            <?php echo e(__('Regenerate Recovery Codes')); ?>

        </button>
    </form>
<?php endif; ?>
<hr>
<?php /**PATH C:\laragon\www\Budget\resources\views/profile/two-factor-authentication-form.blade.php ENDPATH**/ ?>