
<div class="card" style="height: 100vh;">
	<div class="navbar navbar-expand-md flex-md-column flex-row align-items-start pt-0">
		<div class="card-body">
			<ul class="flex-md-column flex-row navbar-nav w-100 justify-content-between">
				<li class="nav-item">
					<a class="nav-link pl-0" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
				</li>
				<li class="nav-item">
					<a class="nav-link pl-0" href="<?php echo e(route('income')); ?>">Income</a>
				</li>
				<li class="nav-item">
					<a class="nav-link pl-0" href="<?php echo e(route('expense')); ?>">Expense</a>
				</li>
				
			</ul>
		</div>
	</div>
</div>

<?php /**PATH C:\laragon\www\Budget\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>